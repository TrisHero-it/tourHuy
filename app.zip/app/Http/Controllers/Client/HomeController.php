<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Banner;
use App\Models\Category;
use App\Models\Blog;
use App\Models\Logo;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $categories = Category::with(['categoryChild', 'tours'])
            ->orderByRaw('CASE WHEN `order` IS NOT NULL THEN `order` ELSE 999 END ASC')
            ->orderBy('created_at', 'desc')
            ->get();
        $banners = Banner::where('status', 'active')->first();
        $blog = Blog::orderBy('id', 'desc')->take(3)->get();
        $logo = Logo::where('status', 'active')->first();
        $categoriesBanner = $categories->where('is_banner', true)->take(6);
        $categoriesFeature = $categories->where('is_featured', true)->take(5);

        return view('client.index', compact('categoriesBanner', 'categoriesFeature', 'blog', 'banners', 'logo'));
    }
}
